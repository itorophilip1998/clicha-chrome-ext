# clicha-chrome-ext


npm install


#Note: there is no git ignore because we need all the file used in the folder